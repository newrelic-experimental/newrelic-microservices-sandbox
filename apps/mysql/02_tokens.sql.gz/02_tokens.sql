create table tokens (
  token VARCHAR(50) NOT NULL,
  customer_id VARCHAR(50) NOT NULL,
  
  PRIMARY KEY (token),
  
  INDEX customer_index (customer_id),
  
  FOREIGN KEY (customer_id)
      REFERENCES customers(id)
      ON DELETE CASCADE
)